import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const API_KEY = process.env.GROQ_API_KEY;

async function main() {
  try {
    const response = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: "llama-3.1-8b-instant", // you can change this to another Groq model
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: "Hello! Can you hear me?" },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(response.data.choices[0].message.content);
  } catch (error) {
    console.error("Error:", error.response?.data || error.message);
  }
}

main();