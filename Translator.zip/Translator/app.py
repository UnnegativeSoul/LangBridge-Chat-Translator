import requests
from dotenv import load_dotenv
import os

from flask import Flask, render_template
from flask_socketio import SocketIO, join_room, leave_room, emit

# Load environment variables
load_dotenv()
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")

# --- Language Detection Helper Function ---
def detect_language(text):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": "Detect the language of the following text and only return the language code (like en, sv, hi, de, ja)."},
            {"role": "user", "content": text}
        ],
        "temperature": 0
    }

    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        return response.json()["choices"][0]["message"]["content"].strip()
    else:
        return "unknown"

# --- Translation Helper Function ---
def translate_text(text, target_lang="en"):
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": "llama-3.1-8b-instant",
        "messages": [
            {"role": "system", "content": f"Translate the following text to {target_lang}. Only return the translation."},
            {"role": "user", "content": text}
        ],
        "temperature": 0.3
    }

    response = requests.post(url, headers=headers, json=data)
    if response.status_code == 200:
        return response.json()["choices"][0]["message"]["content"].strip()
    else:
        return text  # fallback if translation fails

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('join')
def on_join(data):
    room = data['room']
    join_room(room)
    emit('message', {'msg': f"{data['username']} has joined the room."}, room=room)

@socketio.on('leave')
def on_leave(data):
    room = data['room']
    leave_room(room)
    emit('message', {'msg': f"{data['username']} has left the room."}, room=room)

@socketio.on('send_message')
def handle_message(data):
    room = data['room']
    username = data['username']
    msg = data['message']

    # Detect sender's language
    detected_lang = detect_language(msg)

    # Translate message to English
    translated_msg = translate_text(msg, target_lang="en")

    emit('message', {
        'username': username,
        'msg': msg,
        'translated': translated_msg,
        'from_lang': detected_lang
    }, room=room)

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5001)